<?php
// variabel yg menampung alert ketika data sukses di input
$final_data=fileWriteAppend();
     if(file_put_contents('data/data.json', $final_data))
     {
                         echo "<script>
						alert('Data Added Suksess!!');
						document.location='http://localhost/JWD/Tugas8_YunanKholikPauda/TugasAkhir_Pesawat_Terbang/tampil.php';
				     </script>";
     }else{
                         echo "<script>
						alert('Data Added GAGAL!!');
						document.location='http://localhost/JWD/Tugas8_YunanKholikPauda/TugasAkhir_Pesawat_Terbang/tampil.php';
				     </script>";
     }

// function untuk mengambil data json, mengubah menjadi array lalu menambahkan data array baru dan mengubah kembali menjadi json
function fileWriteAppend(){
		$current_data = file_get_contents("data/data.json");
		$array_data = json_decode($current_data, true);
               // code untuk menampung pajak bandara tujuan
               if($_POST['bandara_tujuan'] == "Ngurah Rai (DPS)")
                    $PajakTujuan = 80000;
               elseif($_POST['bandara_tujuan'] == "Hasanuddin (UPG)")
                    $PajakTujuan = 70000;
               elseif($_POST['bandara_tujuan'] == "Inanwatan (INX)")
                    $PajakTujuan = 90000;
               elseif($_POST['bandara_tujuan'] == "Sultan Iskandarmuda (BTJ)")
                    $PajakTujuan = 70000;
                    else(
                          "Data Pajak Bandara Tujuan Tidak Tersedia"
                    );
               // code untuk menampung pajak bandara tujuan
               if($_POST['bandara_asal'] == "Soekarno-Hatta (CGK)")
                    $PajakAsal = 50000;
               elseif($_POST['bandara_asal'] == "Husein Sastranegara (BDO)")
                    $PajakAsal = 30000;
               elseif($_POST['bandara_asal'] == "Abdul Rachman Saleh (MLG)")
                    $PajakAsal = 40000;
               elseif($_POST['bandara_asal'] == "Juanda (SUB)")
                    $PajakAsal = 40000;
                    else(
                          "Data Pajak Bandara Asal Tidak Tersedia"
                    );
                    // variabel yg menampung data baru array
		$extra = array(
             $_POST['maskapai'],
             $_POST['bandara_asal'],
             $_POST['bandara_tujuan'],
             $_POST['harga_tiket'],
             $pajak = $PajakAsal + $PajakTujuan, // variabel untuk menampung total pajak
             $totalharga = $pajak + $_POST['harga_tiket']

		);
		$array_data[] = $extra;
		$final_data = json_encode($array_data);
		return $final_data;
};