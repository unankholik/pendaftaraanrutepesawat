<?php
//Mengambil data json
$data = file_get_contents("data/data.json");
//merubah data json ke array
$json = json_decode($data, TRUE);

//variabel untuk menampung nama bandara asal
$asal = [
    ['BandaraAsal'=> "Soekarno-Hatta (CGK)"],
    ['BandaraAsal'=> "Husein Sastranegara (BDO)"],
    ['BandaraAsal'=> "Abdul Rachman Saleh (MLG)"],
    ['BandaraAsal'=> "Juanda (SUB)"]
];
//variabel untuk menampung nama bandara tujuan
$tujuan =   [
        ['BandaraTujuan'=> "Ngurah Rai (DPS)"],
        ['BandaraTujuan'=> "Hasanuddin (UPG)"],
        ['BandaraTujuan'=> "Inanwatan (INX)"],
        ['BandaraTujuan'=> "Sultan Iskandarmuda (BTJ)"]
];
?>



<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Daftar Rute Pesawat</title>

    <!-- Custom fonts for this template -->
    <link href="library/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="library/bootstrap/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="library/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>
<body>
<div class="container">

	<h1 class="text-center">Pendaftaran Rute Pesawat</h1>

	<!-- Awal Card Form -->
	<div class="card shadow mb-4">
	    <div class="card-header py-3">
	        <h6 class="m-0 font-weight-bold text-primary">Data Rute Pesawat</h6>
	    </div>
	  <div class="card-body">
	        <div class="table-responsive">
			    <form method="post" action="inputjson.php">
					<div class="form-group">
						<label>Maskapai : </label>
						<input type="text" name="maskapai" class="form-control"
						placeholder="Nama Maskapai" required>
					</div>
					<div class="form-group">
						<label>Bandara Asal : </label>
                        <select class="form-control" name="bandara_asal" value="required">
                                <option disabled selected> Pilih Bandara Asal </option>
                                <?php //mengambil data Bandara Asal dari array $asal
                                    foreach($asal as $key){
                                ?>
                                    <option value="<?=$key['BandaraAsal'];?>"><?=$key['BandaraAsal'];?></option>
                                <?php
                                    } //penutup perulangan 
                                ?>
                        </select>
					</div>
                    <div class="form-group">
						<label>Bandara Tujuan : </label>
                        <select class="form-control" name="bandara_tujuan" value="required">
                                <option disabled selected> Pilih Bandara Tujuan </option>     
                                <?php //mengambil data Bandara Tujuan dari array $tujuan
                                    foreach($tujuan as $key){
                                ?>
                                    <option value="<?=$key['BandaraTujuan'];?>"><?=$key['BandaraTujuan'];?></option>
                                <?php
                                    } //penutup perulangan 
                                ?>
                        </select>
					</div>
                    <div class="form-group">
						<label>Harga Tiket : </label>
						<input type="number" name="harga_tiket" class="form-control"
						placeholder="Harga Tiket" required/>
					</div>

			    	<button type="submit" class="btn btn-success" name="bsimpan" style="margin-top: 10px;">Simpan</button>
			    	<button type="reset" class="btn btn-danger" name="breset" style="margin-top: 10px;">Reset</button>
		    	</form>
		    </div>	
	  </div>
	</div>
	<!-- Akhir Card Form -->

	<!-- Awal Card Tabel -->
	<div class="card mt-3">
	  <div class="card-header bg-success text-white">
	    Daftar Rute Pesawat yang Tersedia
	  </div>
	  <div class="card-body">
        <div class="table-responsive">
	        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
	            <thead>
			    	<tr>
			    		<th>Maskapai</th>
	                    <th>Asal Penerbangan</th>
	                    <th>Tujuan Penerbangan</th>
                        <th>Harga Tiket</th>
                        <th>Pajak</th>
                        <th>Total Harga Tiket</th>
	                    <!-- <th>Action</th> -->
			    	</tr>
		    	</thead>
	            <tfoot>
	                <tr>
			    		<th>Maskapai</th>
	                    <th>Asal Penerbangan</th>
	                    <th>Tujuan Penerbangan</th>
                        <th>Harga Tiket</th>
                        <th>Pajak</th>
                        <th>Total Harga Tiket</th>
	                </tr>
	            </tfoot>
	            <tbody> 
			    	<?php //mengambil data Rute Penerbangan dari variabel $json
                        sort($json); // Mengurutkan array sesuai abjad
                        for($brs = 0; $brs <= 6; $brs++){
                           echo "<tr>";
                            for($kol = 0; $kol <= 5; $kol++){
                                echo "<td>".$json[$brs][$kol] . "</td> ";
                            }
                            echo "</tr>";
                        }
                    ?>
		    	</tbody>
		    </table>
	  </div>
	</div>
	<!-- Akhir Card Tabel -->
</div>

<!-- Bootstrap core JavaScript-->
    <script src="library/jquery/jquery.min.js"></script>
    <script src="library/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="library/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="library/bootstrap/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="library/datatables/jquery.dataTables.min.js"></script>
    <script src="library/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="library/bootstrap/js/demo/datatables-demo.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>